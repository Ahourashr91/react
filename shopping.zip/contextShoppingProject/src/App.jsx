import React, { useContext, useState } from 'react'
import './App.css'
import Navbar from './components/Navbar/Navbar'
import Product from './components/Product/Product'
import products from './data'
import Cart from './components/Cart/Cart'
import productsContexts from './contexts/productsContexts'

function App() {
  const [allProducts, setAllProducts] = useState(products)
  const [isShowCart, setIsShowCart] = useState(false)
  const [shoppingCart, setShoppingCart] = useState([])

  return (
    <>
      <productsContexts.Provider value={{
        allProducts,
        setAllProducts,
        isShowCart,
        setIsShowCart,
        shoppingCart,
        setShoppingCart
      }}>
        <Navbar />
        <h1 className='text-center text-light mt-2'>All Products</h1>
        <div>
          <Product />
        </div>
        <Cart />
      </productsContexts.Provider>
    </>
  )
}

export default App
