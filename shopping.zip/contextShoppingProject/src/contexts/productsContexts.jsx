import { createContext } from "react";

const productsContext = createContext()

export default productsContext