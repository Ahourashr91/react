import React, { useContext, useState } from 'react'
import { Navbar } from 'react-bootstrap'
import { FaShoppingBag } from "react-icons/fa";
import productsContexts from './../../contexts/productsContexts'

export default function NavbarCom() {
    const prodContexts = useContext(productsContexts)

    const showHandler = () => {
        prodContexts.setIsShowCart(prev => !prev)
    }

    return (
        <Navbar className="bg-dark">
            <Navbar.Brand className='brand' href="#">React Js Shop</Navbar.Brand>
            <div className='ntp'>
                <Navbar.Text style={{ fontSize: 20, marginLeft: 30 }}>Home</Navbar.Text>
                <Navbar.Text style={{ fontSize: 20, marginRight: 30, cursor: "pointer" }} onClick={showHandler} >Shopping Cart <FaShoppingBag style={{ marginTop: "-5px" }} /></Navbar.Text>
            </div>
        </Navbar>
    )
}
