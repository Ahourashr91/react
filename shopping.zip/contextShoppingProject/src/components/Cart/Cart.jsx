import React, { useContext, useState } from 'react'
import { Offcanvas, Card, Button } from 'react-bootstrap'
import productsContexts from './../../contexts/productsContexts'

export default function Cart() {
    const prodContexts = useContext(productsContexts)

    const showHandler = () => {
        prodContexts.setIsShowCart(prev => !prev)
    }

    console.log(prodContexts.shoppingCart);
    return (
        <>
            <Offcanvas className="bg-dark text-light" onHide={showHandler} show={prodContexts.isShowCart}>
                <Offcanvas.Header style={{ marginTop: 80 }} closeButton >
                    <Offcanvas.Title>Your Cart</Offcanvas.Title>
                </Offcanvas.Header>
                <Offcanvas.Body>
                    {prodContexts.shoppingCart.map(prod => (
                        <Card bg='dark' className='col-md-5 col-lg-3 mt-2' style={{ marginLeft: 10, marginRight: 10, width: '18rem' }}>
                            <Card.Img className='imgbord' variant="top" src={prod.image} />
                            <Card.Body className='text-center'>
                                <Card.Title className='mt-1 text-light'>{prod.title}</Card.Title>
                                <Card.Title className='mt-2 text-light' style={{ fontSize: 18 }}>${prod.price}</Card.Title>
                                <Button className='mt-2' variant="primary">Buy</Button>
                                <Card.Title className='mt-2 text-light' style={{ fontSize: 18 }}>Count: {prod.count}</Card.Title>
                            </Card.Body>
                        </Card>
                    ))}
                </Offcanvas.Body>
            </Offcanvas>
        </>
    )
}
