import React, { useContext, useState } from 'react'
import { Container, Row, Card, Button, Toast } from 'react-bootstrap'
import productsContexts from './../../contexts/productsContexts'

export default function Product() {
    const [showToast, setShowToast] = useState(false)
    const prodContexts = useContext(productsContexts)

    const showToastHandler = () => {
        setShowToast(true)
    }

    const addToCart = (product) => {
        setShowToast()

        const isTekrari = prodContexts.shoppingCart.some(prod => prod.title === product.title)

        if (!isTekrari) {
            const newProduct = {
                id: prodContexts.shoppingCart + 1,
                image: product.image,
                title: product.title,
                price: product.price,
                count: 1
            }
            prodContexts.setShoppingCart(prev => [...prev, newProduct])
            
        } else {
            const newUserCart = prodContexts.shoppingCart.some(prod => {
                if (prod.title === product.title) {
                    prod.count += 1
                    return true
                }
            })
            prodContexts.setShoppingCart(isTekrariSecond)
        }
    }

    return (
        <>
            {prodContexts.allProducts.map(prod => (
                <>
                    <p key={prod.title} className='fs-3 mt-3 text-center'>{prod.title}</p>
                    <Container>
                        <Row className='justify-content-center'>
                            {prod.thisProducts.map(product => (
                                <Card bg='dark' key={product.id} className='col-md-5 col-lg-3 mt-2' style={{ marginLeft: 10, marginRight: 10, width: '18rem' }}>
                                    <Card.Img className='imgbord' variant="top" src={product.image} />
                                    <Card.Body className='text-center'>
                                        <Card.Title className='mt-1 text-light'>{product.title}</Card.Title>
                                        <Card.Title className='mt-2 text-light' style={{ fontSize: 18 }}>${product.price}</Card.Title>
                                        <Button onClick={() => addToCart(product)} className='mt-2' variant="primary">Add To Cart</Button>
                                    </Card.Body>
                                </Card>
                            ))}
                        </Row>
                    </Container >
                </>

            ))}
            <Toast bg='dark' delay={1000} autohide style={{ position: 'fixed', bottom: 10, left: 10, zIndex: 100000 }} onClose={() => setShowToast(false)} show={showToast}>
                <Toast.Body className='text-white'>This Product Added To Your Cart</Toast.Body>
            </Toast>
        </>
    )
}
