import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

export default function Home() {
    const [allProducts, setAllProducts] = useState([])
    const [allOrders, setAllOrders] = useState([])
    const [allusers, setAllUsers] = useState([])
    const [allComments, setAllComments] = useState([])
    const [allOffCodes, setAllOffCodes] = useState([])

    useEffect(() => {
        fetch("http://localhost:3000/products")
            .then(res => res.json())
            .then(products => setAllProducts(products))

        console.log("Products Fetched")

        fetch("http://localhost:3000/users")
            .then(res => res.json())
            .then(users => setAllUsers(users))

        console.log("Users Fetched")

        fetch("http://localhost:3000/orders")
            .then(res => res.json())
            .then(orders => setAllOrders(orders))

        console.log("Orders Fetched")

        fetch("http://localhost:3000/comments")
            .then(res => res.json())
            .then(comments => setAllComments(comments))

        console.log("Comments Fetched")

        fetch("http://localhost:3000/offs")
            .then(res => res.json())
            .then(offCodes => setAllOffCodes(offCodes))
    }, [])

    return (
        <div>
            <h1 className="home-title">سلام به پنل مدیریتی خوش آمدی</h1>
            <div className="home-info-parent">
                <div className="home-information">
                    <div className="info-products"><p>🧍‍♂️تعداد کاربر ها: {allusers.length}</p>  <Link to={"/users"} className="info-link">مشاهده</Link></div>
                    <div className="info-products"><p>📦تعداد محصولات: {allProducts.length}</p>  <Link to={"/products"} className="info-link">مشاهده</Link></div>
                    <div className="info-products"><p>🛒تعداد  سفارش ها: {allOrders.length}</p>  <Link to={"/orders"} className="info-link">مشاهده</Link></div>
                    <div className="info-products"><p>💬تعداد نظرات: {allComments.length}</p>  <Link to={"/comments"} className="info-link">مشاهده</Link></div>
                    <div className="info-products"><p>🎯تعداد کد های تخفیف: {allOffCodes.length}</p>  <Link to={"/offs"} className="info-link">مشاهده</Link></div>
                </div>
            </div>
        </div>
    )
}
