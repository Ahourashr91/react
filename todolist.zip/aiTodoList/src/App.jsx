import React, { useState, useEffect } from 'react';
import './App.css';

export default function App() {
  const [task, setTask] = useState('');
  const [time, setTime] = useState('');
  const [tasks, setTasks] = useState(() => {
    const saved = localStorage.getItem('tasks');
    return saved ? JSON.parse(saved) : [];
  });
  const [showModal, setShowModal] = useState(false);
  const [taskToDelete, setTaskToDelete] = useState(null);
  const [editingId, setEditingId] = useState(null);
  const [editedText, setEditedText] = useState('');
  const [editedTime, setEditedTime] = useState('');
  const [isDarkTheme, setIsDarkTheme] = useState(true)

  useEffect(() => {
    const savedTasks = localStorage.getItem('tasks');
    if (savedTasks) {
      setTasks(JSON.parse(savedTasks));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('tasks', JSON.stringify(tasks));
  }, [tasks]);


  const addTask = () => {
    if (task.trim() === '' || time.trim() === '') return;
    setTasks([...tasks, { id: Date.now(), text: task, time, done: false }]);
    setTask('');
    setTime('');
  };

  const toggleDone = (id) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, done: !t.done } : t));
  };

  const askDeleteTask = (id) => {
    setTaskToDelete(id);
    setShowModal(true);
  };

  const confirmDeleteTask = () => {
    setTasks(tasks.filter(t => t.id !== taskToDelete));
    setShowModal(false);
    setTaskToDelete(null);
  };

  const cancelDelete = () => {
    setShowModal(false);
    setTaskToDelete(null);
  };

  const startEditing = (task) => {
    setEditingId(task.id);
    setEditedText(task.text);
    setEditedTime(task.time);
  };

  const saveEdit = (id) => {
    setTasks(tasks.map(t =>
      t.id === id ? { ...t, text: editedText, time: editedTime } : t
    ));
    setEditingId(null);
  };

  const cancelEdit = () => {
    setEditingId(null);
  };

  const total = tasks.length;
  const completed = tasks.filter(t => t.done).length;
  const pending = total - completed;

  return (
    <div className={`parent ${isDarkTheme ? "darkthemebg" : ""}`}>
      <div className="sub-parent">
        <div className="themeBtn" onClick={() => setIsDarkTheme(!isDarkTheme)}>{isDarkTheme ? <>🌙</> : <>🌞</>}</div>
        <div className="container">
          <h1 className={isDarkTheme ? "darkthemetext" : ""}>React ToDo List</h1>

          <div className={`task-stats ${isDarkTheme ? "darkthemebg2" : ""}`}>
            <span>📋 Total: {total}</span>
            <span>✅ Done: {completed}</span>
            <span>🕗 Pending: {pending}</span>
          </div>

          <div className="input-group">
            <input
              type="text"
              value={task}
              onChange={(e) => setTask(e.target.value)}
              placeholder="New task..."
              className={`task-input ${isDarkTheme? "darkthemebg2" : ""}`}
            />
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className={`task-input ${isDarkTheme? "darkthemebg2" : ""}`}
            />
            <button onClick={addTask} className="add-btn">Add</button>
          </div>

          <ul className="task-list">
            {tasks.map(({ id, text, time, done }) => (
              <li key={id} className={`task-item ${isDarkTheme ? "darkthemebg2" : ""}`}>
                <input
                  type="checkbox"
                  checked={done}
                  onChange={() => toggleDone(id)}
                  className="task-checkbox"
                />

                {editingId === id ? (
                  <div className="task-info">
                    <input
                      type="text"
                      value={editedText}
                      onChange={(e) => setEditedText(e.target.value)}
                      className={`edit-input ${isDarkTheme? "darkthemebg2" : ""}`}
                    />
                    <input
                      type="time"
                      value={editedTime}
                      onChange={(e) => setEditedTime(e.target.value)}
                      className={`edit-time ${isDarkTheme? "darkthemebg2" : ""}`}
                    />
                  </div>
                ) : (
                  <div className="task-info">
                    <span className={`${done ? "task-text done" : "task-text"} ${isDarkTheme ? "darkthemetext" : ""}`}>{text}</span>
                    <span className={`task-time ${isDarkTheme ? "darkthemetext" : ""}`}>🕒 {time}</span>
                  </div>
                )}

                {editingId === id ? (
                  <>
                    <button onClick={() => saveEdit(id)} className="save-btn">Save</button>
                    <button onClick={cancelEdit} className="cancel-btn">Cancel</button>
                  </>
                ) : (
                  <>
                    <button onClick={() => startEditing({ id, text, time })} className="edit-btn">Edit</button>
                    <button onClick={() => askDeleteTask(id)} className="delete-btn">Delete</button>
                  </>
                )}
              </li>
            ))}
          </ul>

          {showModal && (
            <div className="modal-overlay">
              <div className={`modal ${isDarkTheme ? "darkthemebg2" : ""}`}>
                <p>Are you sure you want to delete this task?</p>
                <div className="modal-buttons">
                  <button onClick={confirmDeleteTask} className="confirm-btn">Yes, delete</button>
                  <button onClick={cancelDelete} className="cancel-btn">Cancel</button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
