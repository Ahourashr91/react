import React, { useState } from 'react'
import './App.css'
import { MdDelete } from "react-icons/md";

function App() {

  const [todos, setTodos] = useState([])

  const [todoNameInputValue, setTodoNameinputValue] = useState("")

  const createNewTodo = () => {
    if (todoNameInputValue !== "") {
      const newTodo = {
        id: todos.length + 1,
        name: todoNameInputValue,
      }
      setTodoNameinputValue("")
      setTodos(prevState => [...prevState, newTodo])
    }
    
  }

  const deleteTodo = (todoId) => {
    const newTodos = todos.filter(todo => todo.id !== todoId)

    setTodos(newTodos)
  }


  return (
    <>

      <div className="parent">
        <div>

          <h1>React Todo List</h1>

          <form className="form-parent">
            <input value={todoNameInputValue} onChange={(e) => setTodoNameinputValue(e.target.value)} type="text" className='todoname-input' placeholder='Enter Your Todo Name' />
          </form>

          <div className='addtodo-btn-parent'>
            <button onClick={() => createNewTodo()} className='addtodo-btn'>Add todo</button>
          </div>

          <div className="todos">
            {todos.map(todo => (
              <div key={todo.id} className="todo">
                <p className='todo-name'>{todo.name}</p>
  
                <MdDelete className='deletetodo-icon' onClick={() => deleteTodo(todo.id)} />
              </div>
            ))}
          </div>

        </div>
      </div>

    </>
  )
}

export default App
