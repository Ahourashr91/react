import React, { useState, useEffect, useRef } from "react";
import { FaRegClipboard } from "react-icons/fa";

function Calculator({ theme }) {
    const [expression, setExpression] = useState("");
    const [result, setResult] = useState("");
    const [copied, setCopied] = useState(false);

    const clickSoundRef = useRef(null);

    useEffect(() => {
        clickSoundRef.current = new Audio("/sounds/click.mp3");
    }, []);

    const playClickSound = () => {
        if (clickSoundRef.current) {
            clickSoundRef.current.currentTime = 0;
            clickSoundRef.current.play();
        }
    };

    const buttons = [
        ["(", ")", "C", "←"],
        ["7", "8", "9", "/"],
        ["4", "5", "6", "*"],
        ["1", "2", "3", "-"],
        ["0", ".", "=", "+"],
    ]

    const handleClick = (value) => {
        playClickSound();

        if (value === "C") {
            setExpression("");
            setResult("");
        } else if (value === "←") {
            setExpression(expression.slice(0, -1));
        } else if (value === "=") {
            try {
                const evalResult = eval(expression);
                setResult(evalResult.toString());
            } catch {
                setResult("Error");
            }
        } else {
            setExpression(expression + value);
        }
    };

    const handleCopy = () => {
        if (result) {
            navigator.clipboard.writeText(result);
            setCopied(true);
            setTimeout(() => setCopied(false), 1500);
        }
    };

    const cardClass = theme === "dark" ? "bg-secondary text-white" : "bg-white";
    const inputClass = theme === "dark" ? "bg-dark text-light" : "bg-light";

    return (
        <div className={`card p-4 shadow ${cardClass}`} style={{ maxWidth: "400px", margin: "auto" }}>
            <div style={{ border: "none" }} className={`form-control mb-2 fs-5 text-end ${inputClass}`}>
                {expression || "0"}
            </div>

            <div className="position-relative mb-3">
                {result && (
                    <>
                        <div style={{ border: "none" }} className={`form-control fs-4 text-end pe-5 ${inputClass}`}>
                            {result || ""}
                        </div>
                        <button
                            onClick={handleCopy}
                            className={`position-absolute top-50 translate-middle-y end-0 me-2 btn btn-sm btn-${theme === "dark" ? "outline-light" : "outline-dark"}`}
                            title="Copy to clipboard"
                        >
                            <FaRegClipboard size={16} />
                        </button>
                    </>
                )}
                {copied && (
                    <div className="text-success small text-end mt-1">Copied!</div>
                )}
            </div>

            <div className="d-grid gap-2">
                {buttons.map((row, i) => (
                    <div className="d-flex justify-content-between mb-2" key={i}>
                        {row.map((btn) => (
                            <button
                                key={btn}
                                className={`btn btn-${theme === "dark" ? "dark" : "outline-dark"} flex-fill mx-1`}
                                onClick={() => handleClick(btn)}
                                style={{ width: "50px" }}
                            >
                                {btn}
                            </button>
                        ))}
                    </div>
                ))}
            </div>
        </div>
    );
}

export default Calculator;
