import React, { useEffect, useState } from "react";
import Calculator from "./components/Calculator";
import { CiSun } from "react-icons/ci";
import { GoMoon } from "react-icons/go";

function App() {
  const [theme, setTheme] = useState("");

  useEffect(() => {
    const storedTheme = localStorage.getItem("theme");
    if (storedTheme) {
      setTheme(storedTheme);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("theme", theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === "light" ? "dark" : "light"));
  };

  return (
    <div className={`min-vh-100 ${theme === "dark" ? "bg-dark text-light" : "bg-light text-dark"}`}>
      <div className="container py-5">
        <div style={{direction: "rtl"}}>
          <button className="btn btn-secondary mb-5" onClick={toggleTheme}>
            {theme === "dark" ? (<CiSun className="fs-4" />) : (<GoMoon className="fs-4 "/>)}
          </button>
        </div>
        <Calculator theme={theme} />
      </div>
    </div>
  );
}

export default App;
