import React, { useEffect, useState } from 'react'
import './App.css'

function App() {
  const [questions, setQuestions] = useState([])
  const [currentQuestionNumber, setCurrentQuestionNumber] = useState(0)
  const [correctAnswersCount, setCorrectAnswersCount] = useState(0)
  const [isDarkMode, setIsDarkMode] = useState(true)

  useEffect(() => {
    fetch("http://localhost:3000/questions")
      .then(res => res.json())
      .then(data => setQuestions(data))
  }, [])

  return (
    <>

      <div className={`parent ${isDarkMode ? "darkBG" : ""}`}>
        <p className="change-theme-btn" onClick={() => setIsDarkMode(!isDarkMode)}>{isDarkMode ? "🌙" : "☀️"}</p>
        <div className={`qustionParent ${isDarkMode ? "darkTXT" : ""}`}>
          <h1>History Quiz App</h1>
          {questions.length && currentQuestionNumber !== 10 ? (
            <>
              <p className='questionCount'>
                Question {currentQuestionNumber + 1}/{questions?.length}
              </p>
              <div className="question">
                <p className="questionTitle">{questions[currentQuestionNumber].title}</p>
                <div className="answers row">
                  {questions[currentQuestionNumber].answers.map((answer => (
                    <p key={answer.id} className={`answer-title col-6 ${isDarkMode ? "darkANSWER" : ""}`} onClick={() => {
                      setCurrentQuestionNumber(currentQuestionNumber + 1)
                      if (answer.isCorrect) {
                        setCorrectAnswersCount(correctAnswersCount + 1)
                      }
                    }
                    }>{answer.text}</p>
                  )))}
                </div>
              </div>
            </>
          ) : (<></>)}
          {currentQuestionNumber === 10 ? (
            <>
              <p className='end-quiz-text'>
                You answered {correctAnswersCount !== 0 ? correctAnswersCount : "no"} questions correct!
              </p>
              <div className="btn-parent">
                <a href="" className={`retry-btn btn btn-light ${isDarkMode ? "darkBTN" : ""}`}>Retry</a>
              </div>
            </>
          ) : (<></>)}
        </div>
      </div>
    </>
  )
}

export default App
